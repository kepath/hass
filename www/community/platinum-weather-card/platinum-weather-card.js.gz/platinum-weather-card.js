export{P as PlatinumWeatherCard}from"./platinum-weather-card-006c5bff.js";
